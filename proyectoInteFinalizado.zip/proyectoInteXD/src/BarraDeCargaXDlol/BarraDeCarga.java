package BarraDeCargaXDlol;


public class BarraDeCarga extends javax.swing.JFrame {

   
        public BarraDeCarga() {
        initComponents();
        
        // Crear un hilo para incrementar la barra de progreso
        new Thread(new Runnable() {
            @Override
            public void run() {
                int progreso = 0;  // Valor inicial del progreso
                while (progreso <= 100) {  // Incrementa hasta 100
                    try {
                        Thread.sleep(25);  // Ajusta la velocidad de carga (50 milisegundos entre cada incremento)
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                    barraCarga.setValue(progreso);  // Establece el valor de la barra
                    progreso += 2;  // Incrementa el progreso (ajusta el incremento para cambiar la velocidad de carga)
                }
                // Aquí puedes agregar código para lo que ocurre al finalizar la barra de carga,
                // como cerrar esta ventana y abrir otra, o mostrar un mensaje de éxito.
            }
        }).start();  // Iniciar el hilo
    }


      
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        barraCarga = new javax.swing.JProgressBar();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(0, 204, 255));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setText("Cargando....");
        jPanel1.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 140, -1, -1));
        jPanel1.add(barraCarga, new org.netbeans.lib.awtextra.AbsoluteConstraints(100, 200, 290, 50));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 587, Short.MAX_VALUE)
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 446, Short.MAX_VALUE)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents
        
    
    public static void main(String args[]) {
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new BarraDeCarga().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    public javax.swing.JProgressBar barraCarga;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JPanel jPanel1;
    // End of variables declaration//GEN-END:variables
}
