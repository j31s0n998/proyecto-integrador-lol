/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package AccionDeGrupoFormat;

/**
 *
 * @author ASUS
 */
public class Formato {

    private String[] campos;

    public Formato(String[] campos) {
        this.campos = campos;
    }

    public String[] getCampos() {
        return campos;
    }

    public void setCampos(String[] campos) {
        this.campos = campos;
    }

}
